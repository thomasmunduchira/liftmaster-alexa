const config = {
  requestTimeout: 2250,
  endpoint: 'https://myq.thomasmunduchira.com',
};

module.exports = config;
